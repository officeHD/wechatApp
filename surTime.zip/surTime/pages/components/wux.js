import $wuxCountDown from '../../utils/countdown'

export {
  $wuxCountDown,
}